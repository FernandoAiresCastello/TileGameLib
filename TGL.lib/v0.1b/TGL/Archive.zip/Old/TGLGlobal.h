#pragma once

#include <SDL.h>
#include <string>
#include <vector>
#include <map>
#include "TileGameLib.h"

using namespace std;
using namespace TileGameLib;

extern struct TGL tgl;

typedef int rgb;
